# sniper-bot (paper phase)

Zero-dependency Node (>=18) scanner + paper trader with a Telegram Mini App control panel.
No keys, no signing, no real trades.

Flow: Helius webhook -> Cloudflare Worker (KV) -> phone polls -> gate -> paper position -> exit rules -> logs/paper.jsonl
Panel: Worker serves /app (Telegram Mini App): status, halt, results, editable exit rules. Owner-only (Telegram initData check).

Run (Termux): `cp .env.example .env && nano .env && ./run.sh`
Report: `node src/report.js`
Halt new entries: Mini App button, or `touch HALT`, or POST /halt?on=1 on the Worker
Setup guide: see the PDF.
